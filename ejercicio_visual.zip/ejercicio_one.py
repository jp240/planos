"""name = "manuela gomez"
print("holaa" , name)

# ejemplo de casting (convertir una variable de un tipo de dato a otro)
variable = 5
variable_uno = float(variable)
variable_dos = str(variable)

#sumar_datos = variable + variable_dos
#print(variable, variable_uno)
print(variable, variable_uno, variable_dos)
print(type(variable_dos))
print(type(variable_uno))
print(type(variable))
#print (sumar_datos)

"""

#tipos de datos 
variable1 = "Hola" #str (string)
variable2 = 20 #int (entero)
variable3 = 20.8 #float (decimal)
variable4 = 1j #commplex
variable7 = False #bool (logico)
variable5 = ["cancion", "jugar", "estudiar"] #list
variable6 = ("cancion", "jugar", "estudiar") #tupla
carro = {"color": "rojo", "velocidad": 300, "modelo": "GTRR36"} #dict
#print(variable5)
#print(variable6)
#print(carro) 
print (variable7)