number_one = 68
number_two = 3


#this is a comment of one line 
#operacion de sumar los dos numeros 

""""
this is a multyi_line comment
sumar = number_one + numbre_two

print(sumar)

"""

resta = number_one - number_two
print(resta)
