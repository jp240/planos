#examples of list
#nombres = ["ana", "manu", "laura", "jose"]
print(nombres[2])
#en forma de diccionario
"datos_personales" ["jesus", 33, 1.75, True] en forma de lista 
 = {
   "nombre": "laura", 
    "edad": 33,
      "estatura": 1.75,
        "soltero": True
        }
#print(datos_personas["edad"])

#en forma de tipla
datos_personas = ("jesus", 33, 1.75, True)
print(datos_personas[0])
