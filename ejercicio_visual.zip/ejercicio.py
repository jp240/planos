forma_lavado = "suave"
print(type(forma_lavado)) 
tiempo = "30 minutos"
print(type(tiempo))
detergente= "ariel"
print(type(detergente))
agua = "200ml"
print(type(agua))

