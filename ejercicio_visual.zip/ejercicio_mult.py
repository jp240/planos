number_one = 68
number_two = 3


multiplicacion = number_one * number_two
print(multiplicacion)
